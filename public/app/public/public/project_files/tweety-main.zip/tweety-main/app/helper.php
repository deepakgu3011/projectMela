<?php 

 function current_user(){

	return auth()->user();
}