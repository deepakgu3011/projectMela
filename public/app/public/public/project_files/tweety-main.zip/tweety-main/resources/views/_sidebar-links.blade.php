<ul style="border-radius: 3rem;
padding: 2rem;color:white;">
    <li>
        <a href="{{route('home')}}" class="block mb-4 text-lg font-bold">
            Home
        </a>
    </li>
    <li>
        <a href="/explore" class="block mb-4 text-lg font-bold">
            Explore
        </a>
    </li>
    <li>
        <a href="#" class="block mb-4 text-lg font-bold">
            Notifications
        </a>
    </li>
    <li>
        <a href="#" class="block mb-4 text-lg font-bold">
            Messages
        </a>
    </li>
    <li>
        <a href="#" class="block mb-4 text-lg font-bold">
            Bookmarks
        </a>
    </li>
    <li>
        <a href="#" class="block mb-4 text-lg font-bold">
            Lists
        </a>
    </li>
    <li>
        <a href="{{route('profile', auth()->user())}}" class="block mb-4 text-lg font-bold">
            Profile
        </a>
    </li>
    <li>
        <form method="POST" action="/logout">
            @csrf

            <button class="text-lg font-bold">Logout</button>
        </form>
    </li>
</ul>
