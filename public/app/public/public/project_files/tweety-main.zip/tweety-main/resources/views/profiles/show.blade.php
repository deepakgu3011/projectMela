<x-app>
    <header class="relative mb-6">





  <div class="relative">
            {{-- <img src="{{ $user->getBgImage() }}"
                  alt=""
                  width="700px"
                  height="223px"
                  class="mb-2"
                  style="border-radius: 20px"
            > --}}

            <img src="{{$user->getAvatarAtribute()}}"
                 alt=""
                 class="absolute bottom-0 mr-2 transform -translate-x-1/2 translate-y-1/2 rounded-full"
                 style="left: 50%"
                 width="150"
            >
        </div>





        <div class="flex items-center justify-between mb-6">

          <div style="max-width: 270px">
          	                <h2 class="mb-0 text-2xl font-bold">{{ $user->name }}</h2>
                <p class="text-sm">Joined {{ $user->created_at->diffForHumans() }}</p>
          </div>



				<div class="flex">
					@can('edit',$user)
					<a href="{{ $user->path('edit')}}">
                   		<button type="submit"
                      		 class="px-4 py-2 mr-2 text-xs text-black border border-gray-300 rounded-full">
                      		  Edit Profile
                        </button>
                   </a>

					@endcan

                   <x-follow-button :user="$user">
                   </x-follow-button>

               </div>

        </div>

        <p class="text-sm" style="color: white;">
            The name’s Bugs. Bugs Bunny. Don’t wear it out. Bugs is an anthropomorphic gray
            and white rabbit or hare who is famous for his flippant, insouciant personality.
            He is also characterized by a Brooklyn accent, his portrayal as a trickster,
            and his catch phrase "Eh...What's up, doc?"
        </p>


    </header>

    @include('_timeline', [
        'tweets' =>$tweets
    ])
</x-app>
