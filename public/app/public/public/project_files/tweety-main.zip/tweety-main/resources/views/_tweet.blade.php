<div class="flex p-4 {{ $loop->last ? '' : 'border-b border-b-gray-400' }}">
    <div class="flex-shrink-0 mr-2">
               <a href="{{route('profile',$tweet->user)}}">
               <img src="{{$tweet->user->getAvatarAtribute()}}"
                alt="image"
                class="mr-2 rounded-full"
                width="50"
                height="50">
                </a>
    </div>

    <div style="color: white;">
        <h5 class="mb-4 font-bold">
            <a href="{{route('profile',$tweet->user)}}">
                  {{$tweet->user->name}}
            </a>
        </h5>
        <p class="text-sm">
            {{$tweet->body}}
        </p>
                @auth
            <x-like-buttons :tweet="$tweet" />
        @endauth
    </div>
</div>
