<x-app>
    <div>
             @include('_publish-tweet-panel')
             @include('_timeline')
    </div>

</x-app>