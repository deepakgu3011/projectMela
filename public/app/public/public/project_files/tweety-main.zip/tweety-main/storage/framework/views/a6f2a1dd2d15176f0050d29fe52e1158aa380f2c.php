<div class="px-12 py-8 bg-gray-200 border border-gray-300 rounded-lg">
    <?php if(isset($heading)): ?>
        <div class="font-bold text-lg mb-4"><?php echo e($heading); ?></div>
    <?php endif; ?>

    <?php echo e($slot); ?>

</div><?php /**PATH C:\xampp\htdocs\tweety-main\tweety-main\resources\views/components/panel.blade.php ENDPATH**/ ?>