<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.app','data' => []]); ?>
<?php $component->withName('app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <header class="relative mb-6">





  <div class="relative">
            

            <img src="<?php echo e($user->getAvatarAtribute()); ?>"
                 alt=""
                 class="absolute bottom-0 mr-2 transform -translate-x-1/2 translate-y-1/2 rounded-full"
                 style="left: 50%"
                 width="150"
            >
        </div>





        <div class="flex items-center justify-between mb-6">

          <div style="max-width: 270px">
          	                <h2 class="mb-0 text-2xl font-bold"><?php echo e($user->name); ?></h2>
                <p class="text-sm">Joined <?php echo e($user->created_at->diffForHumans()); ?></p>
          </div>



				<div class="flex">
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit',$user)): ?>
					<a href="<?php echo e($user->path('edit')); ?>">
                   		<button type="submit"
                      		 class="px-4 py-2 mr-2 text-xs text-black border border-gray-300 rounded-full">
                      		  Edit Profile
                        </button>
                   </a>

					<?php endif; ?>

                   <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.follow-button','data' => ['user' => $user]]); ?>
<?php $component->withName('follow-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['user' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($user)]); ?>
                    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

               </div>

        </div>

        <p class="text-sm" style="color: white;">
            The name’s Bugs. Bugs Bunny. Don’t wear it out. Bugs is an anthropomorphic gray
            and white rabbit or hare who is famous for his flippant, insouciant personality.
            He is also characterized by a Brooklyn accent, his portrayal as a trickster,
            and his catch phrase "Eh...What's up, doc?"
        </p>


    </header>

    <?php echo $__env->make('_timeline', [
        'tweets' =>$tweets
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\tweety-main\tweety-main\resources\views/profiles/show.blade.php ENDPATH**/ ?>