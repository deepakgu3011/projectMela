<?php if (! (auth()->user()->is($user))): ?>
<form method="POST" action="/profiles/<?php echo e($user->username); ?>/follow">
  <?php echo csrf_field(); ?>
     <button type="submit"
             class="bg-blue-500 rounded-full shadow py-2 px-4 text-white text-xs mr-2">

             <?php echo e(auth()->user()->following($user)? 'Unfollow Me': 'Follow Me'); ?>

     </button>
</form>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\tweety-main\tweety-main\resources\views/components/follow-button.blade.php ENDPATH**/ ?>