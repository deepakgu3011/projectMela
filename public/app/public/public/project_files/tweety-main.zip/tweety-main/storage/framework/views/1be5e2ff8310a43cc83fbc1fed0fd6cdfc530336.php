<div class="px-8 py-6 mb-8 border border-blue-400 rounded-lg">
    <form method="POST" action="/tweet">
        <?php echo csrf_field(); ?>

        <textarea
            name="body"
            class="w-full"
            placeholder="What's up doc?"
            style="border-radius: 20px;padding: 0.9rem; "
            required
            autofocus
        ></textarea>

        <hr class="my-4">

        <footer class="flex items-center justify-between">
            <img
                src="<?php echo e(auth()->user()->getAvatarAtribute()); ?>"
                alt="your avatar"
                class="mr-2 rounded-full"
                width="50"
                height="50"
            >

            <button
                type="submit"
                class="h-10 px-10 text-sm text-white bg-blue-500 rounded-lg shadow hover:bg-blue-600"
            >
                Publish
            </button>
        </footer>
    </form>

    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\tweety-main\tweety-main\resources\views/_publish-tweet-panel.blade.php ENDPATH**/ ?>